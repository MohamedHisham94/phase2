/*
 * MC2.c

 *
 * Created: 24/04/2019 11:43:48
 * Author: mohamed
 */ 

#include "uart.h"

#define M2_READY 0x10

int main(void)
{

	UART_init(); // initialize UART driver
	UART_sendByte(M2_READY); // MC2 is ready
    uint8 x=UART_recieveByte(); // receive the byte
	//UART_recieveByte();
	DDRC |= (1<<5); // configure pin 5 in PORTC as output pin
	PORTC &= ~(1<<5); // LED OFF
    while(1)
    {

		if(x==1)
					PORTC |= (1<<5); // LED ON
					else
					PORTC &= (~(1<<5)); // LED OFF

    }
}
