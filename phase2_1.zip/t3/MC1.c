/*
 * MC1.c

 *
 * Created: 24/04/2019 11:21:37 PM
 * Author: mohamed
 */ 

#include "uart.h"

#define M2_READY 0x10

int main(void)
{
	UART_init(); // initialize UART
	while(UART_recieveByte() != M2_READY){} // wait until MC2 is ready
	DDRA &= ~(1<<3); // configure pin 3 in PORTA as input pin


	
    while(1)
    {
    	if(PINA & (1<<3))
    		UART_sendByte(1); // send the required byte to MC2
    	else
    		UART_sendByte(0); // send the required byte to MC2
		 _delay_ms(500); //new button every 500ms

    }
}
